%%% Cleans up the workspace - useful to run in case you have any leftovers
%%% from previous MATLAB activity.
clear all

%%% Where the data are stored (see 'Scripts: essential information' for more details). 
% e.g., pathtodata = 'C:\Users\Jen\EEG training\Experiment 1\';
pathtodata = '[ENTER YOUR PATH HERE]';

%%% Where EEGLAB is stored
% e.g., pathtoeeglab = 'C:\Users\Jen\MATLAB\eeglab2021.1';
pathtoeeglab = '[ENTER YOUR PATH HERE]';

%%% Adds the paths
addpath(pathtodata);
addpath(pathtoeeglab);

%%% List your participants. Each participant should have a new line, with
%%% the structure badchans.[dataset name] = { };
%%% e.g., badchans.[Dataset_reampling] = { };
badchans.[ENTER YOUR DATASET NAME HERE];

%%% tells MATLAB what the subject (dataset) names are
subjects = fieldnames(badchans)';

% This just figures out whether we're going to need backslash or
% forwardslash delimiters (i.e., whether we're using pc or unix)
if ismember(1, arrayfun( @(x)(strcmp('\',x)), pathtodata))
    path_delimiter = '\';
else
    path_delimiter = '/';
end;

%%%% New content

%%% the below line tells EEGLAB to conduct the following steps for all
%%% datasets, from 1 to whatever length 'subjects' (our dataset list) is.
for n = 1:length(subjects)
    
    subject = subjects{n}

        %%% Open EEGLAB
        eeglab
        
        %Read Data
        EEG = pop_loadcnt([pathtodata subject '\' subject '.cnt'] , 'dataformat', 'auto', 'memmapfile', '');
        EEG.setname = subject;
        [ALLEEG EEG CURRENTSET] = pop_newset(ALLEEG, EEG, 0,'setname',subject,'gui','off'); 
        EEG = eeg_checkset( EEG );
        
        %Import channel locations
        %Note: Make sure you change the path and file name.
        %e.g., EEG=pop_chanedit(EEG, 'lookup',[pathtoeeglab '\\plugins\\dipfit\\standard_BESA\\standard-10-5-cap385.elp']);
        EEG=pop_chanedit(EEG, 'lookup',[pathtoeeglab '[ENTER YOUR PATH & FILE HERE']);
        [ALLEEG EEG] = eeg_store(ALLEEG, EEG, CURRENTSET);
        EEG = eeg_checkset( EEG );

%%% IMPORTANT: Again, it will seem like nothing exciting has happened here. 
%%% But if you want to check it has worked, you can save the dataset by
%%% using the following code, and open it in the user interface to check 
%%% that channel locations are known:

%%% EEG = eeg_checkset( EEG );
%%% EEG = pop_saveset( EEG, 'filename','(FILENAME HERE).set','filepath','[ADDRESS ON YOUR COMPUTER HERE]');
%%% [ALLEEG EEG] = eeg_store(ALLEEG, EEG, CURRENTSET);      

end;



